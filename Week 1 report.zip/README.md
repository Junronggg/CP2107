Week 1 report submission
